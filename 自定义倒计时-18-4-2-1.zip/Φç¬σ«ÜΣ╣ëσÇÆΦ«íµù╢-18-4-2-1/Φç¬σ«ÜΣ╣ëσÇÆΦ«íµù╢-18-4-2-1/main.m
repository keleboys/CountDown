//
//  main.m
//  自定义倒计时-18-4-2-1
//
//  Created by zq on 2018/4/2.
//  Copyright © 2018年 zq. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
